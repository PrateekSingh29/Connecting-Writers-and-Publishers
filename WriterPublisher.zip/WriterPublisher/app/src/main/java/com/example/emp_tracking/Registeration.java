package com.example.emp_tracking;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import publisher.writer.com.writerpublisher.R;
public class Registeration extends Activity {

	String strFirstname = "";
	String strLastname = "";
	String strusername = "";
	String strpassword = "";
	String strFathername = "";
	String strMobile = "";
	String strEmailid = "";
	String strAddress = "";
	String strUsertype = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registeration);
		TextView tvtitle = (TextView) findViewById(R.id.tvUser);
		Intent i = getIntent();
		String title = i.getStringExtra("title");
		tvtitle.setText(title);
		strUsertype = i.getStringExtra("usertype");
		System.out.println("usertype=" + strUsertype);
		final EditText etFirstname = (EditText) findViewById(R.id.etFirstName);
		final EditText etLastname = (EditText) findViewById(R.id.etLastname);
		final EditText etusername = (EditText) findViewById(R.id.etusername1);
		final EditText etpassword = (EditText) findViewById(R.id.etpassword);
		final EditText etFathername = (EditText) findViewById(R.id.etfathername);
		final EditText etMobile = (EditText) findViewById(R.id.etmobile);
		final EditText etEmailid = (EditText) findViewById(R.id.etemailid);
		final EditText etAddress = (EditText) findViewById(R.id.etaddress);
		Button btnSubmit = (Button) findViewById(R.id.btnSubmit);

		btnSubmit.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					strFirstname = etFirstname.getText().toString();
					strLastname = etLastname.getText().toString();

					strusername = etusername.getText().toString();
					strpassword = etpassword.getText().toString();
					strFathername = etFathername.getText().toString();
					strMobile = etMobile.getText().toString();
					strEmailid = etEmailid.getText().toString();
					strAddress = etAddress.getText().toString();
				} catch (Exception e) {
					e.printStackTrace();
				}

				System.out.println("name=" + strFirstname + ":" + strLastname
						+ ":" + strusername + ":" + strUsertype);
				Context context = Registeration.this;
				String title = "Warning!!";
				String message = "Save Details";
				String button1String = "Save";
				String button2String = "Cancel";
				AlertDialog.Builder ad = new AlertDialog.Builder(context);
				ad.setTitle(title);
				ad.setMessage(message);
				ad.setPositiveButton(button1String, new OnClickListener() {

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						DateFormat dateFormat = new SimpleDateFormat(
								"dd/MM/yyyy");
						DateFormat dateFormat1 = new SimpleDateFormat(
								"HH:mm:ss");

						Calendar cal = Calendar.getInstance();

						String reg_date = dateFormat.format(cal.getTime());// "11/03/14 12:33:43";
						String reg_time = dateFormat1.format(cal.getTime());
						if (verifyLastName(strFirstname)) {
							if(strEmailid.contains("@")&&strEmailid.contains(".")){
								DBAdapter db1 = new DBAdapter(getBaseContext());
								db1.open();

								long check = db1.registerUser(strusername,
										strUsertype, strpassword, strFirstname,
										strLastname, strFathername, strMobile,
										strEmailid, strAddress, reg_date, reg_time,
										"True");
								db1.close();
								if (check == -1) {
									Toast.makeText(getBaseContext(),
											"An error occured!!",
											Toast.LENGTH_SHORT).show();
								} else if (check > 0) {

									Toast.makeText(getBaseContext(), "Saved!!",
											Toast.LENGTH_SHORT).show();
									finish();
								}
							}else{
								Toast.makeText(getBaseContext(), "Please enter a valid emailid",
										Toast.LENGTH_SHORT).show();
							}
							
							
						}else{
							Toast.makeText(getBaseContext(), "Name should be alphabetical only",
									Toast.LENGTH_SHORT).show();
							
						}

					}
				});
				ad.setNegativeButton(button2String, new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						Toast.makeText(getBaseContext(), "Canceled!",
								Toast.LENGTH_SHORT).show();
						finish();
					}
				});

				ad.show();

			}
		});

	}

	private boolean verifyLastName(String lname) {
		lname = lname.trim();

		if (lname == null || lname.equals(""))
			return false;

		if (!lname.matches("[a-zA-Z]*"))
			return false;

		return true;
	}
}