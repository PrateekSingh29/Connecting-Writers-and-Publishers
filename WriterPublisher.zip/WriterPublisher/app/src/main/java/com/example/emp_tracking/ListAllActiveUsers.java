package com.example.emp_tracking;

import java.util.ArrayList;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import publisher.writer.com.writerpublisher.R;



public class ListAllActiveUsers extends Activity{
	
	
String username;
	ArrayList<String>lstUserid=new ArrayList<String>();
	ArrayList<String>lstDetails=new ArrayList<String>();
	ListView list;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.list_offers);
		username= getIntent().getStringExtra("username");
		list=(ListView) findViewById(R.id.list);
		DBAdapter db=new DBAdapter(getBaseContext());
		db.open();
		Cursor c=db.getAllRegisteredUser("user");
		while(c.moveToNext()){
			lstUserid.add(c.getString(c.getColumnIndex("username")));
			lstDetails.add(c.getString(c.getColumnIndex("firstname"))+c.getString(c.getColumnIndex("lastname")));
		}
		c.close();
		db.close();
		Adapter1 adapter=new Adapter1(getBaseContext(), R.layout.custum_list, lstDetails);
		list.setAdapter(adapter);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getBaseContext(),UserProfile.class);
				i.putExtra("username",lstUserid.get(position));
				startActivity(i);
			}
		});
		
	}

	
}
