package com.example.emp_tracking;

import java.io.File;
import java.util.ArrayList;



import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import publisher.writer.com.writerpublisher.R;

public class ViewItems extends Activity {

	ArrayList<String> lstItems = new ArrayList<String>();
	ArrayList<String> lstUserDetails = new ArrayList<String>();
	ArrayList<String> lstMobile = new ArrayList<String>();
	ArrayList<String> lstItemid = new ArrayList<String>();
	ArrayList<String> lstImg = new ArrayList<String>();
	ArrayAdapter<String> adapter;
	ImageView imgRoute;
	String phone_no;
	Button btnCall;
	ListView listItems;
	TextView tvDetails;
	EditText txtSearch;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_route);
		listItems = (ListView) findViewById(R.id.listitems);
		tvDetails = (TextView) findViewById(R.id.tvDetails);
		imgRoute = (ImageView) findViewById(R.id.imgROute);
		txtSearch = (EditText) findViewById(R.id.txtSearch);


tvDetails.setText("");
	}

	public void getDetails(View v) {
		String search = txtSearch.getText().toString();

		DBAdapter db = new DBAdapter(getBaseContext());
		lstImg.clear();
		lstItemid.clear();
		lstItems.clear();
		lstMobile.clear();
		lstUserDetails.clear();

		tvDetails.setText("");

try{
	db.open();
	Cursor c = db.getItemsByKey(search);


	while (c.moveToNext()) {


		lstImg.add(c.getString(c.getColumnIndex("item_img")));
		lstItemid.add(c.getString(c.getColumnIndex("_id")));
		Cursor c1 = db.getUserByUsername((c.getString(c
				.getColumnIndex("userid"))));
		if (c1.moveToNext()) {
			lstItems.add("ISDN NO.: "+ c.getString(c.getColumnIndex("item_ISDN"))+
					"\nBook Name: "+ c.getString(c.getColumnIndex("item_name"))
					+"\nBook Price: "+ c.getString(c.getColumnIndex("item_price"))
					+"\nPrice: "+ c.getString(c.getColumnIndex("page"))
					+"\nBook Title: "+ c.getString(c.getColumnIndex("title"))
					+"\nBook Author: "+ c1.getString(c1.getColumnIndex("firstname"))
					//+"\nOffered Price: "+ c.getString(c.getColumnIndex("offeredPrice"))
					+ "\nItem Description: "+ c.getString(c.getColumnIndex("item_desc")));
			lstUserDetails.add("Userid: "
					+ c.getString(c.getColumnIndex("userid")) + "\nName: "
					+ c1.getString(c1.getColumnIndex("firstname")));
			lstMobile.add(c1.getString(c1.getColumnIndex("mobile")));
		}

	}
}catch (Exception e){
	e.printStackTrace();
}

		if (lstImg.size() > 0) {
			Adapter1 adapter = new Adapter1(ViewItems.this,
					R.layout.custum_list, lstItems);
			listItems.setAdapter(adapter);
			listItems.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// TODO Auto-generated method stub
try
{
	final File targetLocation = new File(lstImg.get(position));
	Log.i(AppConstant.tag, targetLocation.getPath());
	tvDetails.setText(lstUserDetails.get(position));
	phone_no = lstMobile.get(position);
	imgRoute.setImageBitmap(BitmapFactory
			.decodeFile(targetLocation.getPath()));
	imgRoute.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_VIEW);
			intent.setDataAndType(
					Uri.parse("file://"
							+ targetLocation.getPath()),
					"image/*");
			startActivity(intent);
		}
	});
	if (targetLocation.exists()) {
		Toast.makeText(getBaseContext(),
				"Click on Image to zoom!!", Toast.LENGTH_SHORT)
				.show();
	} else {
		Toast.makeText(getBaseContext(), "No Image Found!!",
				Toast.LENGTH_SHORT).show();
	}
}catch (Exception e){e.printStackTrace();}


				}
			});
		}else{
			Toast.makeText(getBaseContext(), "No books Found", Toast.LENGTH_SHORT).show();
		}

	}

}
