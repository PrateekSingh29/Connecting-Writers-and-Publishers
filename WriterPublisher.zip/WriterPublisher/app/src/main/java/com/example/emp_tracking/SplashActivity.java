package com.example.emp_tracking;

import publisher.writer.com.writerpublisher.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import publisher.writer.com.writerpublisher.R;
public class SplashActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		TextView imageView = (TextView) findViewById(R.id.tvtimer);
		Animation animation = AnimationUtils.loadAnimation(
				getApplicationContext(), R.anim.abc);
		imageView.startAnimation(animation);

		Thread thread = new Thread() {
			public void run() {
				try {
					sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				SplashActivity.this.finish();
			
				/*Intent i = new Intent(SplashActivity.this, MainActivity.class);
				startActivity(i);*/
				Intent i = new Intent(SplashActivity.this, LoginActivity.class);
			
				startActivity(i);

			}

		};

		thread.start();
	}
}