package com.example.emp_tracking;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;



import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import publisher.writer.com.writerpublisher.R;
public class PostItem extends Activity{
	EditText txtName,txtDesc,txtISDN,txtPrice,txtPage,txtTitle,txtAuthor,txtOfferedPrice;
	CheckBox cbxDonate;
	//TextView tvImg;
	String userid;
	ImageView imgDisplay;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.create_item);
	userid=getIntent().getStringExtra("username");
	txtName=(EditText) findViewById(R.id.txtLocName);
	txtDesc=(EditText) findViewById(R.id.txtAddress);
	txtISDN=(EditText) findViewById(R.id.txtISDN);
	txtPrice=(EditText) findViewById(R.id.txtPrice);
	txtPage=(EditText) findViewById(R.id.txtPage);
	txtTitle=(EditText) findViewById(R.id.txtTitle);
	txtAuthor=(EditText) findViewById(R.id.txtAuthor);
	txtOfferedPrice=(EditText) findViewById(R.id.txtOfferedPrice);
	cbxDonate=(CheckBox) findViewById(R.id.cbxDonate);
	imgDisplay=(ImageView) findViewById(R.id.imgDisplay);
	File f=new File(AppConstant.sdcard);
	
	if(!f.exists()){
		f.mkdir();
	}
}
private static final int CAMERA_REQUEST = 0;
public void clickImage(View v){
	 Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
     startActivityForResult(cameraIntent, CAMERA_REQUEST); 
}
@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	super.onActivityResult(requestCode, resultCode, data);

	  if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {  
            Bitmap photo = (Bitmap) data.getExtras().get("data"); 
            imgDisplay.setImageBitmap(photo);
            fileName=AppConstant.sdcard+getDate()+".png";
            FileOutputStream out = null;
            try {
                out = new FileOutputStream(fileName);
                photo.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
                // PNG is a lossless format, the compression factor (100) is ignored
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

          
        }  
}
/*
 * Cuts selected file name from real path to show in screen.
 */
private String getStringNameFromRealPath(final String bucketName) {
	return bucketName.lastIndexOf('/') > 0 ? bucketName
			.substring(bucketName.lastIndexOf('/') + 1) : bucketName;
}
@SuppressLint("SimpleDateFormat")
public String getDate() {
	DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");
	// DateFormat dateFormat1 = new SimpleDateFormat("HH:mm:ss");

	Calendar cal = Calendar.getInstance();

	String reg_date = dateFormat.format(cal.getTime());// "11/03/14 12:33:43";
	// String reg_time = dateFormat1.format(cal.getTime());
	return reg_date;

}
String fileName="hh";

public void saveLocation(View v){
	String lname=txtName.getText().toString();
	String ldesc=txtDesc.getText().toString();
	String isdn=txtISDN.getText().toString();
	String price=txtPrice.getText().toString();
	String page=txtPage.getText().toString();
	String title=txtTitle.getText().toString();
	String author=txtAuthor.getText().toString();
	String offeredPrice=txtOfferedPrice.getText().toString();
	File f=new File(fileName);
	if(f.exists()){
		if(lname.length()>0&&ldesc.length()>0&&page.length()>0&&title.length()>0&&price.length()>0){
			if(isdn.length()>0){
				if(price.length()>0){
				String donate="false";
				if(	cbxDonate.isChecked()){
					donate="true";
				}
					DBAdapter db=new DBAdapter(getBaseContext());
					db.open();
					
					long l=db.saveItems(lname, ldesc, fileName, "true",userid,isdn,donate,price,page,title,author,offeredPrice);
					db.close();
					if(l>0){
						Toast.makeText(getBaseContext(), "Book saved successfully!!", Toast.LENGTH_SHORT).show();
					}else{
						Toast.makeText(getBaseContext(), "Failed to save item!!", Toast.LENGTH_SHORT).show();
					}
				}else {
					Toast.makeText(getBaseContext(), "Please enter book price", Toast.LENGTH_SHORT).show();
				}
			}else{
				Toast.makeText(getBaseContext(), "Please enter book isdn no.", Toast.LENGTH_SHORT).show();
			}
			
		}else{
			Toast.makeText(getBaseContext(), "Please check all the fields", Toast.LENGTH_SHORT).show();
		}
	}else{
		Toast.makeText(getBaseContext(), "Please select an Image", Toast.LENGTH_SHORT).show();
	}
	
	
	
}
}
