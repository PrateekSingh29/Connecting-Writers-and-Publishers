package com.example.emp_tracking;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import publisher.writer.com.writerpublisher.R;

public class UserProfile extends Activity {
	TextView tvusername;
	String username;
@Override
protected void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.profile);
	tvusername=(TextView) findViewById(R.id.tvusername);
	Intent i=getIntent();
	username=i.getStringExtra("username");

	DBAdapter db=new DBAdapter(this);	
	db.open();
	Cursor c=db.getUserByUsername(username);
	if(c.moveToNext()){
		username=c.getString(c.getColumnIndex("username"));
		final String userdetails = "\nUserid: "+c.getString(0)+"\nUsername:"+c.getString(1)+"\nUser Type:"+c.getString(2)+"\nName:"+c.getString(5)
				+" "+c.getString(6)+"\nFather's Name: "+c.getString(4)+"\nMobile: "+c.getString(7)+"\nEmail id: "+c.getString(8)+"\nAddress: "+c.getString(9)+"\nRegisration Date: "+c.getString(10);
		tvusername.setText(userdetails);
	}
				
	
			
	db.close();
	
	
}


}
