package com.example.emp_tracking;

import android.os.Environment;

public class AppConstant {
	public static final String sdcard = Environment.getExternalStorageDirectory().toString()+"/navigation/";
	public static String tag="LOC";
	
}
