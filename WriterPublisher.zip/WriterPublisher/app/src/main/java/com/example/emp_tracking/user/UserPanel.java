package com.example.emp_tracking.user;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.emp_tracking.ChangePassword;
import com.example.emp_tracking.LoginActivity;
import com.example.emp_tracking.PostItem;

import com.example.emp_tracking.UserProfile;
import com.example.emp_tracking.ViewItems;

import publisher.writer.com.writerpublisher.R;

public class UserPanel extends Activity {
	 String username;
	 TextView tvCurrentLoc ;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_panel);
		Intent i = getIntent();
		  username = i.getStringExtra("username");
		String firstname = i.getStringExtra("firstname");
		System.out.println("Activity started " + firstname);
		TextView tvWelcome = (TextView) findViewById(R.id.tvWelcome);
		 tvCurrentLoc = (TextView) findViewById(R.id.tvCurrentLoc);
		tvWelcome.setText("Welcome " + firstname);
		Button btnStudentProfile = (Button) findViewById(R.id.btnStudProfile);
		
	
		
		Button btnLogout=(Button)findViewById(R.id.btnStudLogout);
		Button btnChangePass=(Button)findViewById(R.id.btnChangePassStud);
		btnChangePass.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getBaseContext(), ChangePassword.class);
				i.putExtra("username", username);
			
				startActivity(i);
			}
		});
		btnLogout.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i1 = new Intent(getBaseContext(),
						LoginActivity.class);
				i1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i1);
			}
		});
		btnStudentProfile.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getBaseContext(), UserProfile.class);

				i.putExtra("usertype", "Admin");
				i.putExtra("username", username);
				i.putExtra("user_detail", "student");
				startActivity(i);
			}
		});
	verifyStoragePermissions(UserPanel.this);
		
	}
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };

    /**
     * Checks if the app has permission to write to device storage
     * <p>
     * If the app does not has permission then the user will be prompted to grant permissions
     *
     * @param activity
     */
    public int verifyStoragePermissions(Activity activity) {
        // Check if we have write permission

        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }

        return permission;
    }
public void search(View v){
	Intent i = new Intent(getBaseContext(), ViewItems.class);

	i.putExtra("usertype", "user");
	i.putExtra("username", username);
	i.putExtra("user_detail", "student");
	startActivity(i);

}
	public void save(View v){
		Intent i = new Intent(getBaseContext(), PostItem.class);

		i.putExtra("usertype", "user");
		i.putExtra("username", username);
		i.putExtra("user_detail", "student");
		startActivity(i);
	}


	@Override
protected void onResume() {
	// TODO Auto-generated method stub
	super.onResume();

}
}
