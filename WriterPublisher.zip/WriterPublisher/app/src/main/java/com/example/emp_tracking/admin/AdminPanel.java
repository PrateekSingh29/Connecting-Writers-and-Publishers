package com.example.emp_tracking.admin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.emp_tracking.AdminProfile;
import com.example.emp_tracking.ChangePassword;
import com.example.emp_tracking.ListAllActiveUsers;
import com.example.emp_tracking.LoginActivity;
import com.example.emp_tracking.ViewItems;
import com.example.emp_tracking.util.SystemUiHider;

import publisher.writer.com.writerpublisher.R;
/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 * 
 * @see SystemUiHider
 */
public class AdminPanel extends Activity {
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main_admin);
		Intent i = getIntent();
		final String username = i.getStringExtra("username");
		String firstname = i.getStringExtra("firstname");
		TextView tvusername=(TextView) findViewById(R.id.tvusername);
		tvusername.setText("Welcome "+firstname);
		
		
		Button btnRegisterMissingPerson=(Button) findViewById(R.id.btnRegisterMissingPerson);
		Button btnProfile=(Button) findViewById(R.id.btnProfile);
		Button btnViewAllRegisteredUser=(Button) findViewById(R.id.btnViewAllRegisteredUser);
	
		Button btnLogout=(Button)findViewById(R.id.btnLogout);
		
		Button btnChangePass=(Button)findViewById(R.id.btnChangePassAdmin);
		btnChangePass.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getBaseContext(), ChangePassword.class);
				i.putExtra("username", username);			
				startActivity(i);
			}
		});
		
		
		btnLogout.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i1 = new Intent(getBaseContext(),
						LoginActivity.class);
				i1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i1);
			}
		});
			
	
		btnProfile.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getBaseContext(),AdminProfile.class);
			
				i.putExtra("usertype", "Admin");
				i.putExtra("username", username);	
				i.putExtra("user_detail", "admin_profile");	
				startActivity(i);
				
			}
		});
		btnRegisterMissingPerson.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getBaseContext(),ViewItems.class);

				i.putExtra("usertype", "Admin");
				i.putExtra("username", username);
				i.putExtra("user_detail", "admin_profile");
				startActivity(i);
				
			}
		});
		btnViewAllRegisteredUser.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getBaseContext(),ListAllActiveUsers.class);
				i.putExtra("usertype", "admin_view_all");
				startActivity(i);
				
			}
		});
	

	}

}
