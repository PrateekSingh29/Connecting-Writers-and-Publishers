package com.example.emp_tracking;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class DBAdapter {
	public static final String KEY_ROWID = "_id";// to save id //
	public static final String KEY_USERNAME = "username"; //
	public static final String KEY_PASSWORD = "password_"; //
	public static final String KEY_USERTYPE = "usertype"; //
	public static final String KEY_FIRSTNAME = "firstname"; //
	public static final String KEY_LASTNAME = "lastname"; //
 	public static final String KEY_FATHERNAME ="fathername";
	public static final String KEY_MOBILE = "mobile"; //
	public static final String KEY_EMAILID = "emailid"; //
	public static final String KEY_ADDRESS = "address"; //
	public static final String KEY_DATE = "date1";// to save date of registration table
	public static final String KEY_TIME = "time1";// to save time
	public static final String KEY_STATUS = "status";// to check status of task
	private static final String TAG ="db";// for database adapter
	public static final String DATABASE_NAME = "PUBLISHER"; //$NON-NLS-1$
	public static final String DATABASE_TABLE = "REGISTERATION"; //$NON-NLS-1$
	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_CREATE = "create table REGISTERATION (_id integer primary key autoincrement, " //$NON-NLS-1$
			+ "username text unique not null,usertype text not null, password_ text not null,fathername text not null,firstname text not null,lastname text not null,mobile text not null,emailid text unique not null,address text not null, date1 text not null, time1 text not null, status text not null);"; //$NON-NLS-1$
		public static final String KEY_ITEM_NAME = "item_name";
	public static final String KEY_ITEM_PRICE = "item_price";
	public static final String KEY_ITEM_ISDN = "item_ISDN";
	public static final String KEY_ITEM_DONATE = "item_donate";
	public static final String KEY_ITEM_DESC = "item_desc";
	public static final String KEY_ITEM_page = "page";
	public static final String KEY_title = "title";
	public static final String KEY_author = "author";
	public static final String KEY_offeredPrice = "offeredPrice";
	public static final String KEY_status = "status";
	public static final String KEY_IMG = "item_img";
	public static final String DATABASE_TABLE_ITEMS = "books"; // to

	private static final String DATABASE_CREATE_ITEM = "create table "+DATABASE_TABLE_ITEMS+" (_id integer primary key autoincrement, " //$NON-NLS-1$
			+ "item_name text not null,item_ISDN text unique not null,"
			+ "item_price text not null,item_donate text not null,"
			+ "item_desc text not null, item_img text not null,"
			+ "status text not null,userid text not null,"
			+ "page text not null,title text not null,"
			+ "author text not null,offeredPrice text not null);"; //$NON-NLS-1$
	private final Context context;
	private DatabaseHelper DBHelper;
	private static SQLiteDatabase db;

	public DBAdapter(Context ctx) {
		// super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			try {
				db.execSQL(DATABASE_CREATE);
				db.execSQL(DATABASE_CREATE_ITEM);
				saveInitialValues(db);
				Log.w(TAG, "database created "); //$NON-NLS-1$
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		private static void save(SQLiteDatabase db, String username,
				String usertype, String password, String firstname,
				String lastname, String fathername, String mobile,
				String emailid, String address, String date, String time,
				String status) {
			ContentValues initialValues = new ContentValues();
			initialValues.put(KEY_USERNAME, username);
			initialValues.put(KEY_PASSWORD, password);
			initialValues.put(KEY_USERTYPE, usertype);
			initialValues.put(KEY_FIRSTNAME, firstname);
			initialValues.put(KEY_LASTNAME, lastname);
			initialValues.put(KEY_FATHERNAME, fathername);
			initialValues.put(KEY_MOBILE, mobile);
			initialValues.put(KEY_EMAILID, emailid);
			initialValues.put(KEY_ADDRESS, address);
			initialValues.put(KEY_DATE, date);
			initialValues.put(KEY_TIME, time);
			initialValues.put(KEY_STATUS, status);

			db.insert(DATABASE_TABLE, null, initialValues);
		}

		private static void saveInitialValues(SQLiteDatabase db) {

			save(db,
					"Admin", "admin", "asdfgh", "Admin", "", "ABCDE", "989898998", "admin@gmail.com", "Delhi", "21/10/2013", "18:44:25", "True"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$
			save(db,
					"User", "user", "asdfgh", "Writer1", "", "ABCDE", "989898998", "user@gmail.com", "Delhi", "21/10/2013", "18:44:25", "True"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to " //$NON-NLS-1$ //$NON-NLS-2$
					+ newVersion + ", which will destroy all old data"); //$NON-NLS-1$
			db.execSQL("DROP TABLE IF EXISTS tasks"); //$NON-NLS-1$
			onCreate(db);// to create db
		}
	}
	public long saveItems(String lname,
						  String ldesc, String img,String status,String userid,String isdn,String donate,String price, String page, String title, String author, String offeredPrice) {
		ContentValues initialValues = new ContentValues();

		initialValues.put(KEY_ITEM_NAME, lname);
		initialValues.put(KEY_ITEM_PRICE, price);
		initialValues.put(KEY_ITEM_ISDN, isdn);
		initialValues.put(KEY_ITEM_DONATE, donate);
		initialValues.put(KEY_ITEM_DESC, ldesc);

		initialValues.put(KEY_IMG, img);
		initialValues.put(KEY_status, status);
		initialValues.put("userid", userid);
		initialValues.put(KEY_ITEM_page, page);
		initialValues.put(KEY_title, title);
		initialValues.put(KEY_author, author);
		initialValues.put(KEY_offeredPrice, offeredPrice);
		return db.insert(DATABASE_TABLE_ITEMS, null, initialValues);

	}

	public int activateUser(String userna) {

		ContentValues args = new ContentValues();

		args.put(KEY_STATUS, "True");

		return db.update(DATABASE_TABLE, args, KEY_USERNAME
				+ "=" + "'" + userna + "'", null); //$NON-NLS-1$

	}

	// ---opens the database---
	public DBAdapter open() throws SQLException {
		db = DBHelper.getWritableDatabase();
		return this;
	}

	// ---closes the database---
	public void close() {
		DBHelper.close();
	}

	/*
	 * private static final String DATABASE_CREATE_APPOINT = "create table " +
	 * DATABASE_TABLE_APPOINT + " (_id integer primary key autoincrement, "
	 * //$NON-NLS-1$ + "" + KEY_f_userid + " text not null," + KEY_USERID +
	 * " text not null," + KEY_APPOINTMENT_TIME +
	 * " text not null,"+KEY_APPOINT_DATE
	 * +" text not null,"+KEY_APPOINTMENT_TIME+" text null,status text null);";
	 * //$NON-NLS-1$
	 */

	public String getDate() {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		// DateFormat dateFormat1 = new SimpleDateFormat("HH:mm:ss");

		Calendar cal = Calendar.getInstance();

		String reg_date = dateFormat.format(cal.getTime());// "11/03/14 12:33:43";
		// String reg_time = dateFormat1.format(cal.getTime());
		return reg_date;

	}

	public Cursor getItemsByKey(String key) {
		String sql;
if(key==null){
	sql="select * from "+DATABASE_TABLE_ITEMS;
}else
		 sql="select * from "+DATABASE_TABLE_ITEMS+" where "+KEY_ITEM_NAME+" like '%"+key+"%'";
		Log.i(AppConstant.tag, sql);
		Cursor c=db.rawQuery(sql, null);

		return c;

	}
	// ---register a user into the database---
	public long registerUser(String username, String usertype, String password,
			String firstname, String lastname, String fathername,
			String mobile, String emailid, String address, String date,
			String time, String status) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_USERNAME, username);
		initialValues.put(KEY_PASSWORD, password);
		initialValues.put(KEY_USERTYPE, usertype);
		initialValues.put(KEY_FIRSTNAME, firstname);
		initialValues.put(KEY_LASTNAME, lastname);
		initialValues.put(KEY_FATHERNAME, fathername);
		initialValues.put(KEY_MOBILE, mobile);
		initialValues.put(KEY_EMAILID, emailid);
		initialValues.put(KEY_ADDRESS, address);
		initialValues.put(KEY_DATE, date);
		initialValues.put(KEY_TIME, time);
		initialValues.put(KEY_STATUS, status);

		return db.insert(DATABASE_TABLE, null, initialValues);

	}

	// ---deletes a particular contact---
	public boolean deleteContact(long rowId) {
		return db.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0; //$NON-NLS-1$
	}

	public int getRows() {
		String sql = "SELECT COUNT(*) FROM " + DATABASE_TABLE; //$NON-NLS-1$

		SQLiteStatement statement = db.compileStatement(sql);
		long count = statement.simpleQueryForLong();
		return (int) count;

	}

	// ---retrieves all the contacts---
	public Cursor getAllRegisteredActiveUser() {

		return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_USERNAME,
				KEY_USERTYPE, KEY_FIRSTNAME, KEY_LASTNAME, KEY_FATHERNAME,
				KEY_MOBILE, KEY_ADDRESS, KEY_EMAILID, KEY_DATE, KEY_TIME,
				KEY_STATUS },
				KEY_STATUS + "=" + "'True'", null, null, null, null); //$NON-NLS-1$ //$NON-NLS-2$

	}

	public Cursor getAllRegisteredUser() {

		return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_USERNAME,
				KEY_USERTYPE, KEY_FIRSTNAME, KEY_LASTNAME, KEY_FATHERNAME,
				KEY_MOBILE, KEY_ADDRESS, KEY_EMAILID, KEY_DATE, KEY_TIME,
				KEY_STATUS }, null, null, null, null, KEY_ROWID + " desc");

	}

	public Cursor getAllRegisteredUser(String type) {

		return db.rawQuery("select * from " + DATABASE_TABLE
				+ " where usertype='" + type + "'", null);

	}



	public Cursor getValidRegisteredUser() {

		return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_USERNAME,
				KEY_USERTYPE, KEY_FIRSTNAME, KEY_LASTNAME, KEY_FATHERNAME,
				KEY_MOBILE, KEY_ADDRESS, KEY_EMAILID, KEY_DATE, KEY_TIME,
				KEY_STATUS }, KEY_STATUS + "=" + "'True'", null, null, null,
				null);

	}

	public Cursor getValidRegisteredUserExceptSelf(String username) {

		return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_USERNAME,
				KEY_USERTYPE, KEY_FIRSTNAME, KEY_LASTNAME, KEY_FATHERNAME,
				KEY_MOBILE, KEY_ADDRESS, KEY_EMAILID, KEY_DATE, KEY_TIME,
				KEY_STATUS }, KEY_STATUS + "=" + "'True'" + " and "
				+ KEY_USERNAME + "!=" + "'" + username + "'", null, null, null,
				null);

	}

	public int updatePassword(String username, String password) {
		ContentValues args = new ContentValues();

		args.put(KEY_PASSWORD, password);

		return db.update(DATABASE_TABLE, args, KEY_USERNAME
				+ "=" + "'" + username + "'", null); //$NON-NLS-1$

	}

	public Cursor getAllRegisteredUserWithPassword() {

		return db.query(DATABASE_TABLE, new String[] { KEY_ROWID, KEY_USERNAME,
				KEY_USERTYPE, KEY_PASSWORD, KEY_FIRSTNAME, KEY_EMAILID,
				KEY_STATUS }, null, null, null, null, null);

	}

	// ---retrieves a particular contact---
	public Cursor getUserById(long rowId) throws SQLException {
		Cursor mCursor = db.query(DATABASE_TABLE, new String[] { "*" },
				KEY_ROWID + "=" + rowId, null, null, null, null); //$NON-NLS-1$

		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public Cursor getUserMobileByEmail(String email) throws SQLException {
		Cursor mCursor = db.query(DATABASE_TABLE, new String[] { KEY_MOBILE,
				KEY_PASSWORD },
				KEY_EMAILID + "=" + "'" + email + "'", null, null, null, null); //$NON-NLS-1$

		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public Cursor getUserByUsername(String username) throws SQLException {
String sql="select * from "+DATABASE_TABLE+" where "+KEY_USERNAME+"='"+username+"'";
        Log.i(TAG, "getUserByUsername: "+sql
        );
        Cursor mCursor=db.rawQuery(sql,null);
		System.out.println(KEY_USERTYPE + "=" + "'" + username + "'");

		return mCursor;
	}

	public Cursor getUserByUserID(String username) throws SQLException {
		Cursor mCursor = db
				.query(DATABASE_TABLE,
						new String[] { "*" },
						KEY_ROWID
								+ "=" + "'" + username + "' and usertype!='admin' || usertype!='user'", null, null, null, null); //$NON-NLS-1$

		System.out.println(KEY_USERTYPE + "=" + "'" + username + "'");
		if (mCursor != null) {
			return mCursor;
		}
		return mCursor;
	}

	public Boolean validateUser(String username, String password)
			throws SQLException {
		Cursor mCursor = db
				.query(DATABASE_TABLE,
						new String[] { KEY_USERNAME, KEY_STATUS },
						KEY_USERNAME
								+ "=" + "'" + username + "'" + " and " + KEY_PASSWORD + "=" + "'" + password + "'", null, null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

		if (mCursor != null) {
			return true;
		}
		return false;
	}

	// ---updates a contact---
	public boolean updateContact(String username, String password,
			String firstname, String lastname, String mobile, String emailid,
			String address) {
		ContentValues args = new ContentValues();
		args.put(KEY_FIRSTNAME, firstname);
		args.put(KEY_LASTNAME, lastname);
		args.put(KEY_PASSWORD, password);

		args.put(KEY_MOBILE, mobile);
		args.put(KEY_EMAILID, emailid);
		args.put(KEY_ADDRESS, address);

		return db.update(DATABASE_TABLE, args,
				KEY_USERNAME + "=" + username, null) > 0; //$NON-NLS-1$
	}

	// ---updates a contact---
	public boolean deactivateUser(String username) {
		ContentValues args = new ContentValues();

		args.put(KEY_STATUS, "False");

		return db.update(DATABASE_TABLE, args, KEY_USERNAME
				+ "=" + "'" + username + "'", null) > 0; //$NON-NLS-1$
	}

}
